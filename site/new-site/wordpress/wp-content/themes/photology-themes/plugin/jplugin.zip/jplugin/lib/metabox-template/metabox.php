<div class="jeg-meta-tab">
	<?php echo $content; ?>
</div>
	