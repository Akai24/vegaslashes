<div>	
	<div class="alert alert-info"><strong><?php echo $title; ?></strong> <?php echo $content; ?> </div>
</div>