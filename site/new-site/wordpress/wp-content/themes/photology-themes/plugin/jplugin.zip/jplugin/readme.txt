1.0.0
- Initial Release

1.0.1
- Update font awesome to 4.2.0

1.0.2
- Add wordpress importer script

1.0.3
- VC additional element

1.0.4
- Remove Image size checker on WordPress Importer that causing image import failed

1.0.5
- Add Functionality for image metabox
- Fix issues with fontawesome with the backend
- Remove Jquery Include script on Framework
- Add new type element, Ajax Button Call on Admin Option

1.0.6
- prevent problem when reactivate plugin

1.0.7
- fix deprecated wp_richedit_pre
- fix issues with metabox upload

1.0.8
- Change phtml to php
- Option Panel no need for Jeg Vesion anymore
- Add Hook on admin panel
- WP Alchemy to use PHP 7 Style Constructor