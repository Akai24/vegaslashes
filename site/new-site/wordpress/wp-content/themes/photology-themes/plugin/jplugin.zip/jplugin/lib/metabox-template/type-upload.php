<div class="meta-option">	
	<h4 class="meta-title"><?php echo $title ?>:</h4>
	<?php echo jeg_create_metabox_nonce($id); ?>
	<div class="uploadfile">
		<?php $value = $default ? $default : ""; ?>
		<input type="text" class="uploadtext" name="<?php echo $id; ?>" id="<?php echo $id; ?>" value="<?php echo $value; ?>" />
		<input type="button" value="Select File" class="selectfile"/>
	</div>	
	<span class="meta-description"><?php echo $description; ?></span>
</div>
