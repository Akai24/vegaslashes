<div class="meta-option">	
	<h4 class="meta-title"><?php echo $title ?>:</h4>
	<?php echo jeg_create_metabox_nonce($id); ?>
	<select id="<?php echo $id; ?>" name="<?php echo $id; ?>">
		<?php foreach ($option as $key => $value) : ?>
		<?php $choose = ( $default == $key ) ? "selected='selected'" : ''; ?>
		<option value="<?php echo $key; ?>"  <?php echo $choose ?> ><?php echo $value; ?></option>
		<?php endforeach; ?>		
	</select>
	<span class="meta-description"><?php echo $description; ?></span>
</div>