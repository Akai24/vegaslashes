<div class="meta-option">	
	<h4 class="meta-title"><?php echo $title ?>:</h4>
	<?php echo jeg_create_metabox_nonce($id); ?>
	<?php $value = $default ? $default : ""; ?>
	<input type="text" name="<?php echo $id; ?>" id="<?php echo $id; ?>" value="<?php echo $value; ?>" />
	<span class="meta-description"><?php echo $description; ?></span>
</div>
