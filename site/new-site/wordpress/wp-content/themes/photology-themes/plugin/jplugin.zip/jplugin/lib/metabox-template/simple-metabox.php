<div>
	<div>
		<?php echo $content; ?>		
	</div>	
</div>
	