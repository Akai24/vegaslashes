<?php

return array(
    'id'          => 'photology_portfolio_link',
    'types'       => array('portfolio'),
    'title'       => 'Link to another page',
    'priority'    => 'high',
    'template'    => array(

        array(
            'type' => 'textbox',
            'name' => 'portfolio_link',
            'label' => 'Link to another page',
        ),


    ),
);