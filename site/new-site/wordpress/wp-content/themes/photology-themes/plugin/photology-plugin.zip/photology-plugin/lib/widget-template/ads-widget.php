<div class="blog-sidebar-square-ads">
	<a href="<?php echo $adsurl; ?>"><img src="<?php echo $adsimage; ?>" style="max-width: <?php echo $adsize; ?>px;"></a>
</div>