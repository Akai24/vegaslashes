= Photology =

* by Jegtheme, http://jegtheme.com/forum

== 1.0.0 ==
- Initial Release

== 1.0.1 ==
- Fix mobile menu issues

== 1.0.2 ==
- Fix initial creating of portfolio issues
- Ability to install plugin from child themes

== 1.0.3 ==
- Add option to add google maps key
